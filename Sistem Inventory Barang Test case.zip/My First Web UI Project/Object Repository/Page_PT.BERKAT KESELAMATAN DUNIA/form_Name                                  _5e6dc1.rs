<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Name                                  _5e6dc1</name>
   <tag></tag>
   <elementGuidId>75dd2f18-1a51-4902-b795-92d352e903b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>form</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@action='http://ptberkatkeselamatandunia.epizy.com/register']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>a6d48825-01f7-444e-8618-9ffb2e0a76f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>POST</value>
      <webElementGuid>c14d79c9-9d59-49bf-8110-a2c3372ef0f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>action</name>
      <type>Main</type>
      <value>http://ptberkatkeselamatandunia.epizy.com/register</value>
      <webElementGuid>7faa6b62-71e5-4eb0-bd65-d3ae19663ff4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                        
                            Name

                            
                                

                                                            
                        

                        
                            E-Mail Address

                            
                                

                                                            
                        

                        
                            Password

                            
                                

                                                            
                        

                        
                            Confirm Password

                            
                                
                            
                        
                        
                            Role
                        
                            
                            Admin
                            
                            Karyawan

                        
                        

                        

                        
                            
                                
                                    Register
                                
                            
                        
                    </value>
      <webElementGuid>d5add525-85d0-45fc-802b-5d4cc01c0f6c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/main[@class=&quot;py-4&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row justify-content-center&quot;]/div[@class=&quot;col-md-8&quot;]/div[@class=&quot;card&quot;]/div[@class=&quot;card-body&quot;]/form[1]</value>
      <webElementGuid>63a2834b-9763-4df1-9917-b75059c9264f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@action='http://ptberkatkeselamatandunia.epizy.com/register']</value>
      <webElementGuid>59a70ac2-4d18-414e-b4e0-2a0b449d8200</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/main/div/div/div/div/div[2]/form</value>
      <webElementGuid>c13e791d-5a04-4b32-9652-2b2adacdbed2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register'])[2]/following::form[1]</value>
      <webElementGuid>5e42c2aa-d4a9-4125-91f7-80dd68b07382</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register'])[1]/following::form[1]</value>
      <webElementGuid>06c61c94-79f2-4772-8892-7f804a50acfd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
      <webElementGuid>4a357868-893b-4c3f-9bee-b4f8bc095097</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[(text() = '
                        
                        
                            Name

                            
                                

                                                            
                        

                        
                            E-Mail Address

                            
                                

                                                            
                        

                        
                            Password

                            
                                

                                                            
                        

                        
                            Confirm Password

                            
                                
                            
                        
                        
                            Role
                        
                            
                            Admin
                            
                            Karyawan

                        
                        

                        

                        
                            
                                
                                    Register
                                
                            
                        
                    ' or . = '
                        
                        
                            Name

                            
                                

                                                            
                        

                        
                            E-Mail Address

                            
                                

                                                            
                        

                        
                            Password

                            
                                

                                                            
                        

                        
                            Confirm Password

                            
                                
                            
                        
                        
                            Role
                        
                            
                            Admin
                            
                            Karyawan

                        
                        

                        

                        
                            
                                
                                    Register
                                
                            
                        
                    ')]</value>
      <webElementGuid>e83d7616-c74e-4dfe-baf5-fa83b3ca5c5d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
