<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_show_chart                               _df30cb</name>
   <tag></tag>
   <elementGuidId>34798906-ca07-4517-b21a-3b38f19ce316</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sidenav-collapse-main']/ul/li[7]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3c50e414-a606-40c8-8d68-4af630dca981</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-link text-white </value>
      <webElementGuid>953f9443-4c1d-4d81-b37f-8b9d338985cd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://ptberkatkeselamatandunia.epizy.com/stokopnames</value>
      <webElementGuid>974c63d4-fc6a-4562-8e92-6ffcc8b167d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            show_chart
                        
                        Stok Opname
                    </value>
      <webElementGuid>37b25fd4-f6b5-471c-8df7-c859fed0d9f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;g-sidenav-show  bg-gray-200&quot;]/main[@class=&quot;main-content position-relative max-height-vh-100 h-100 border-radius-lg ps&quot;]/aside[@id=&quot;sidenav-main&quot;]/div[@id=&quot;sidenav-collapse-main&quot;]/ul[@class=&quot;navbar-nav&quot;]/li[@class=&quot;nav-item&quot;]/a[@class=&quot;nav-link text-white&quot;]</value>
      <webElementGuid>c362a57f-e0cf-43b8-abea-1ab23633800a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sidenav-collapse-main']/ul/li[7]/a</value>
      <webElementGuid>a4089899-f5b8-4da1-8b0a-fa6170f4f141</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Multi Satuan'])[1]/following::a[1]</value>
      <webElementGuid>9c1e22b5-c53c-4f82-9b76-e90486b69cdc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='track_changes'])[1]/following::a[1]</value>
      <webElementGuid>e869c218-0eb8-482e-944d-7de4d88228ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[@href='http://ptberkatkeselamatandunia.epizy.com/stokopnames']</value>
      <webElementGuid>9054dd51-a9d3-4cb2-b9fd-d156b3a0d7c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[7]/a</value>
      <webElementGuid>be477952-d809-498f-bb15-cffbcef38637</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://ptberkatkeselamatandunia.epizy.com/stokopnames' and (text() = '
                        
                            show_chart
                        
                        Stok Opname
                    ' or . = '
                        
                            show_chart
                        
                        Stok Opname
                    ')]</value>
      <webElementGuid>c62692ff-9096-4c78-8e3e-9e97ab8fa00c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
