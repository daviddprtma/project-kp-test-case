<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Safety Glasses                      _f09776</name>
   <tag></tag>
   <elementGuidId>7fa753f7-c60f-4baa-b3ca-71e26f825787</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@name='iditems']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>select[name=&quot;iditems&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>5185ac57-4aa8-418d-83c9-4af7f35f9a37</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>iditems</value>
      <webElementGuid>3c1d6c10-6284-422d-897c-ed29717bd3f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>aacc9918-fe1d-4f60-b48f-9bff4907c01e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                    Safety Glasses
                                                    Safety Helmet
                                                    Safety Gloves
                                                    Boots Safety Strength PVC
                                                    High Visibility
                                                    Masker 3 Ply
                                                    Kacamata Renang
                                                    tes
                                            </value>
      <webElementGuid>179f6511-af39-46a3-a0c2-f901c4f9d4fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;g-sidenav-show  bg-gray-200&quot;]/main[@class=&quot;main-content position-relative max-height-vh-100 h-100 border-radius-lg ps ps--active-y&quot;]/div[@class=&quot;container-fluid px-2 px-md-4&quot;]/div[@class=&quot;card card-body mx-3 mx-md-4 mt-n6&quot;]/form[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12 px-1&quot;]/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>18e1de98-e222-4f13-ab39-14efc6289893</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@name='iditems']</value>
      <webElementGuid>35b47f82-06f6-4d8c-b0a8-192bc5bb0305</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nama Barang'])[1]/following::select[1]</value>
      <webElementGuid>2cb74211-bd91-48a5-87a3-39b03d57f235</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tanggal Keluar'])[1]/following::select[1]</value>
      <webElementGuid>a5f9d739-54cf-4674-b8fe-12cb464cfbad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nama Perusahaan'])[1]/preceding::select[1]</value>
      <webElementGuid>6a724d5c-76bb-48bc-91c6-97dda9ae7d77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Satuan'])[1]/preceding::select[1]</value>
      <webElementGuid>54e6d6ff-1701-40f8-a159-6caee6567ad8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>d311dbca-ec0c-401c-a4f1-e33939ccd80d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'iditems' and (text() = '
                                                    Safety Glasses
                                                    Safety Helmet
                                                    Safety Gloves
                                                    Boots Safety Strength PVC
                                                    High Visibility
                                                    Masker 3 Ply
                                                    Kacamata Renang
                                                    tes
                                            ' or . = '
                                                    Safety Glasses
                                                    Safety Helmet
                                                    Safety Gloves
                                                    Boots Safety Strength PVC
                                                    High Visibility
                                                    Masker 3 Ply
                                                    Kacamata Renang
                                                    tes
                                            ')]</value>
      <webElementGuid>23db4e42-593b-4414-b535-506bd5699a18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nama Barang Masuk'])[1]/following::select[1]</value>
      <webElementGuid>f9f30d78-254d-41fc-91e1-bef234998783</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tanggal Masuk'])[1]/following::select[1]</value>
      <webElementGuid>24fe65e8-3983-42fc-9755-5951c5cd30cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Jumlah Barang Masuk'])[1]/preceding::select[1]</value>
      <webElementGuid>b15fb01b-442c-43d3-b761-85a8542129d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Satuan Barang'])[1]/preceding::select[1]</value>
      <webElementGuid>9f1baf6e-7521-4bee-bb38-dee9ba1b9483</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
