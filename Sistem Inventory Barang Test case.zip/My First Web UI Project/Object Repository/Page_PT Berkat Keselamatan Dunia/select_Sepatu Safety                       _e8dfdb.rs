<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Sepatu Safety                       _e8dfdb</name>
   <tag></tag>
   <elementGuidId>4d4c6395-2563-47f1-9476-9739e90bb37a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@name='category_id']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>select[name=&quot;category_id&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>6a7a3f19-3ffa-417e-9078-367b22a91b42</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>category_id</value>
      <webElementGuid>cdf8b889-15a8-451f-8f54-b50427438892</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>54971a50-3c82-4441-b9df-f14e4e153750</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                            Sepatu Safety
                                                            Sepatu
                                                            Helm Safety
                                                            Kacamata
                                                            Sarung Tangan
                                                            Rompi Kerja
                                                            Masker
                                                            Sarung Tangan Kain
                                                    </value>
      <webElementGuid>eac5800d-ad44-4582-b0f6-9613b6e8003f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;g-sidenav-show  bg-gray-200&quot;]/main[@class=&quot;main-content position-relative max-height-vh-100 h-100 border-radius-lg ps ps--active-y&quot;]/div[@class=&quot;container-fluid px-2 px-md-4&quot;]/div[@class=&quot;card card-body mx-3 mx-md-4 mt-n6&quot;]/form[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12 px-1&quot;]/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>78b314a3-336f-438e-b090-dbb2efc5c36b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@name='category_id']</value>
      <webElementGuid>77ada384-2625-4158-8731-874c7137d635</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kategori Barang'])[3]/following::select[1]</value>
      <webElementGuid>fce68895-f496-468a-87e8-1158e6d8b052</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gambar Stok'])[1]/following::select[1]</value>
      <webElementGuid>1dd11409-c44d-48b3-aab7-4731c8bd68ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Satuan'])[1]/preceding::select[1]</value>
      <webElementGuid>1669c492-fa53-42a7-9292-4ef3dc7d294d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tambah Stok'])[1]/preceding::select[2]</value>
      <webElementGuid>8ce7bcf4-e224-4b94-8fe9-3aca30c329f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>67c386b2-0f37-427c-b104-e786945d56be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'category_id' and (text() = '
                                                            Sepatu Safety
                                                            Sepatu
                                                            Helm Safety
                                                            Kacamata
                                                            Sarung Tangan
                                                            Rompi Kerja
                                                            Masker
                                                            Sarung Tangan Kain
                                                    ' or . = '
                                                            Sepatu Safety
                                                            Sepatu
                                                            Helm Safety
                                                            Kacamata
                                                            Sarung Tangan
                                                            Rompi Kerja
                                                            Masker
                                                            Sarung Tangan Kain
                                                    ')]</value>
      <webElementGuid>06837510-7e72-4036-8769-ce747c3c1f92</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
