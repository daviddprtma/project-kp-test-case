<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Next_ps__rail-y</name>
   <tag></tag>
   <elementGuidId>325f19d2-509e-40df-94c1-5add7a3af886</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>main.main-content.position-relative.max-height-vh-100.h-100.border-radius-lg.ps.ps--active-y > div.ps__rail-y</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Next'])[1]/following::div[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c6919502-aa47-4ed9-9b8c-388be9847461</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ps__rail-y</value>
      <webElementGuid>28e6b005-3720-4120-8334-7e7c5b8adb8e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;g-sidenav-show  bg-gray-200&quot;]/main[@class=&quot;main-content position-relative max-height-vh-100 h-100 border-radius-lg ps ps--active-y&quot;]/div[@class=&quot;ps__rail-y&quot;]</value>
      <webElementGuid>af95282d-42a4-41f3-82e8-00254286d5a8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Next'])[1]/following::div[3]</value>
      <webElementGuid>4e419e26-22fb-4dfe-a640-24fa0557614a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous'])[1]/following::div[3]</value>
      <webElementGuid>51eaaa55-3c3d-44bf-a68d-4864ec733bfd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div[3]</value>
      <webElementGuid>e746fbcc-826b-4c72-9b50-a22ccd2eb32c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kembali'])[1]/following::div[3]</value>
      <webElementGuid>0c5b4f61-b640-4e38-a69b-d6a7a47af060</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Update Stok Keluar'])[1]/following::div[3]</value>
      <webElementGuid>df87c832-1827-48ab-a206-bfe00d54c688</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='picture_as_pdf'])[3]/following::div[3]</value>
      <webElementGuid>09f7b8f1-f3ea-471b-bcbb-80114dfd1b8c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submit'])[1]/following::div[3]</value>
      <webElementGuid>2eb2e3ac-3060-4d6b-aca4-80c3a40dc2a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Update Stok Masuk'])[1]/following::div[3]</value>
      <webElementGuid>bd7d25a2-1454-4694-9037-37eb40a68509</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kirim'])[1]/following::div[3]</value>
      <webElementGuid>75bcda45-6cd9-4da2-8191-dacf4f9c04b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tambah Stok'])[1]/following::div[3]</value>
      <webElementGuid>c1d6c52c-6ca3-45ec-bcab-9b9803386902</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
