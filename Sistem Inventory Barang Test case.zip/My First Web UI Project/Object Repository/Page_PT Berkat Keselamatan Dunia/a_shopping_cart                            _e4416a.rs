<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_shopping_cart                            _e4416a</name>
   <tag></tag>
   <elementGuidId>1e0cb09a-4f2b-4ef0-9e61-bf11a5ab4e76</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='sidenav-collapse-main']/ul/li[4]/a)[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7463104d-63ca-41b6-b024-296620a4e396</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-link text-white </value>
      <webElementGuid>02c0ae67-9b5d-4f9f-8525-d6ebeb1afda2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://ptberkatkeselamatandunia.epizy.com/initems</value>
      <webElementGuid>485a7fa5-9e95-46fb-951d-b021b9fef30a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            shopping_cart
                        
                        Pencatatan Stok Masuk
                    </value>
      <webElementGuid>50e8cf77-7730-41fb-972e-b45c73934766</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;g-sidenav-show  bg-gray-200&quot;]/main[@class=&quot;main-content position-relative max-height-vh-100 h-100 border-radius-lg ps&quot;]/aside[@id=&quot;sidenav-main&quot;]/div[@id=&quot;sidenav-collapse-main&quot;]/ul[@class=&quot;navbar-nav&quot;]/li[@class=&quot;nav-item&quot;]/a[@class=&quot;nav-link text-white&quot;]</value>
      <webElementGuid>c8e83027-bde3-437b-a5f7-c346622d5439</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='sidenav-collapse-main']/ul/li[4]/a)[2]</value>
      <webElementGuid>7dd8bedf-2f12-48a8-b29d-69b21fd51c34</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Master Barang'])[1]/following::a[1]</value>
      <webElementGuid>50d48986-ea1d-4c57-8e12-575f7f460d86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='table_view'])[2]/following::a[1]</value>
      <webElementGuid>b7a03a08-b56f-4899-aa58-b893d128a8e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[@href='http://ptberkatkeselamatandunia.epizy.com/initems']</value>
      <webElementGuid>55423425-a602-4760-a06c-25701b51828a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[4]/a</value>
      <webElementGuid>3b56c35b-98d6-42d8-a7a1-09c5e85be2b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://ptberkatkeselamatandunia.epizy.com/initems' and (text() = '
                        
                            shopping_cart
                        
                        Pencatatan Stok Masuk
                    ' or . = '
                        
                            shopping_cart
                        
                        Pencatatan Stok Masuk
                    ')]</value>
      <webElementGuid>1dd97f87-af55-460d-a9b2-a479b62ee17c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
