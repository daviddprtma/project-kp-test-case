<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_track_changes                            _d928df</name>
   <tag></tag>
   <elementGuidId>995cc884-0c38-43dd-b44f-6cc7cfaa93dd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='sidenav-collapse-main']/ul/li[6]/a)[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>da037747-ceab-4533-af7e-22096cd41fa3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-link text-white </value>
      <webElementGuid>f23a5d62-ed85-4a48-a7a2-4e1020333951</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://ptberkatkeselamatandunia.epizy.com/units</value>
      <webElementGuid>b29e371d-7ec4-489a-81bb-57123d2ead87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            track_changes
                        
                        Multi Satuan
                    </value>
      <webElementGuid>b32bc25a-695c-4366-bed9-d117cefe8f3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;g-sidenav-show  bg-gray-200&quot;]/main[@class=&quot;main-content position-relative max-height-vh-100 h-100 border-radius-lg ps&quot;]/aside[@id=&quot;sidenav-main&quot;]/div[@id=&quot;sidenav-collapse-main&quot;]/ul[@class=&quot;navbar-nav&quot;]/li[@class=&quot;nav-item&quot;]/a[@class=&quot;nav-link text-white&quot;]</value>
      <webElementGuid>2f35e9b7-697b-4119-94f1-e175139a2128</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='sidenav-collapse-main']/ul/li[6]/a)[2]</value>
      <webElementGuid>58281046-1aba-4bb2-937a-15f3d2f911b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pencatatan Stok Keluar'])[1]/following::a[1]</value>
      <webElementGuid>ad931d33-ef32-4aca-8ec2-15b7ac141649</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='local_shipping'])[1]/following::a[1]</value>
      <webElementGuid>5482d83f-ab95-48f0-816e-229fbf992c80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[@href='http://ptberkatkeselamatandunia.epizy.com/units']</value>
      <webElementGuid>c7010753-96ed-47fb-93e1-373c23d110e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[6]/a</value>
      <webElementGuid>ec92412b-526f-49ee-8cd1-1733cc5c39b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://ptberkatkeselamatandunia.epizy.com/units' and (text() = '
                        
                            track_changes
                        
                        Multi Satuan
                    ' or . = '
                        
                            track_changes
                        
                        Multi Satuan
                    ')]</value>
      <webElementGuid>53cff018-f809-48d2-914f-ccd0b86acc7d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
