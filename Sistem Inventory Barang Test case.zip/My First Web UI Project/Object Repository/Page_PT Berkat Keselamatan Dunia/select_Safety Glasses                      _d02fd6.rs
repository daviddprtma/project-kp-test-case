<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Safety Glasses                      _d02fd6</name>
   <tag></tag>
   <elementGuidId>870e2a50-9fbb-4ff4-8459-4a150b91f6a1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>select[name=&quot;iditems&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@name='iditems']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>afa5a2e8-5297-49d8-9c8a-a3218537dd2f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>iditems</value>
      <webElementGuid>59329e13-8c7e-4ace-92d7-f25232f8692d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>59a4e195-cf5a-42f1-9cb0-3f6f487361e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                            Safety Glasses
                                                            Safety Helmet
                                                            Safety Gloves
                                                            Boots Safety Strength PVC
                                                            High Visibility
                                                            Masker 3 Ply
                                                            Kacamata Renang
                                                            tes
                                                    </value>
      <webElementGuid>ccc92dc3-1a71-40af-961d-61294984a75a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;g-sidenav-show  bg-gray-200&quot;]/main[@class=&quot;main-content position-relative max-height-vh-100 h-100 border-radius-lg ps&quot;]/div[@class=&quot;container-fluid px-2 px-md-4&quot;]/div[@class=&quot;card card-body mx-3 mx-md-4 mt-n6&quot;]/form[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12 px-1&quot;]/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>c7006cc7-3df0-4d1a-9399-17cc5efa6308</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@name='iditems']</value>
      <webElementGuid>d671dbca-711d-4501-9aa9-0100b1353570</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nama Barang'])[1]/following::select[1]</value>
      <webElementGuid>80510d87-abd9-4967-ad76-4337fb2d9e48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LOGOUT'])[2]/following::select[1]</value>
      <webElementGuid>7056829a-2994-4ee5-a12d-f3e8b2f9180a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Jumlah Barang Opname'])[1]/preceding::select[1]</value>
      <webElementGuid>e74df405-23b8-4968-8e98-5797d6c7da6f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Update Barang'])[1]/preceding::select[1]</value>
      <webElementGuid>93576a8b-f00a-43f1-badc-36bdaabf760d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>41b8985f-5a1f-489d-8bdd-4941d412d188</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'iditems' and (text() = '
                                                            Safety Glasses
                                                            Safety Helmet
                                                            Safety Gloves
                                                            Boots Safety Strength PVC
                                                            High Visibility
                                                            Masker 3 Ply
                                                            Kacamata Renang
                                                            tes
                                                    ' or . = '
                                                            Safety Glasses
                                                            Safety Helmet
                                                            Safety Gloves
                                                            Boots Safety Strength PVC
                                                            High Visibility
                                                            Masker 3 Ply
                                                            Kacamata Renang
                                                            tes
                                                    ')]</value>
      <webElementGuid>5ac774ec-c78d-4995-b92f-14963974f2c5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
