<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Masker</name>
   <tag></tag>
   <elementGuidId>fe978665-1b64-4330-a0b3-28155a4733df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='category']/tbody/tr[3]/td[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>ba94b219-a4e3-4614-8287-0d86fdd64fb8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>align-middle text-sm</value>
      <webElementGuid>a1c352a0-2801-4a9f-a9e2-41e2975a1809</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                Masker
                                                
                                            </value>
      <webElementGuid>5a6f054c-a8c9-47f5-9e2b-ca32eba2f882</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;category&quot;)/tbody[1]/tr[@class=&quot;odd&quot;]/td[@class=&quot;align-middle text-sm&quot;]</value>
      <webElementGuid>a70709cd-6de4-4da2-94e5-04ae71529a64</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='category']/tbody/tr[3]/td[2]</value>
      <webElementGuid>10c398da-d54e-490e-bf72-dcdf83221092</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Batal'])[3]/following::td[1]</value>
      <webElementGuid>be0c6ba9-83b4-4ecc-aa38-5b8199bd0aee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Unggah Foto Baru'])[3]/following::td[1]</value>
      <webElementGuid>4f35d9fd-e546-4332-a3ec-f754102459f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Masker berfungsi untuk melindungi dari debu'])[1]/preceding::td[1]</value>
      <webElementGuid>353f5393-4449-4c35-90de-94bb4a313c1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[3]/td[2]</value>
      <webElementGuid>9c530b1a-2c01-419e-9b10-04e2db3f5c7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = '
                                                Masker
                                                
                                            ' or . = '
                                                Masker
                                                
                                            ')]</value>
      <webElementGuid>81436aa9-fbb3-4990-bd6d-2cc8cd1e8fcf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
