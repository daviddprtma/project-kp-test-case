<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_table_view                               _50a094</name>
   <tag></tag>
   <elementGuidId>08ab7407-3459-4257-a1a7-bcc37ee0c7da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='sidenav-collapse-main']/ul/li[3]/a)[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>85f992e7-e532-4f25-bd75-9251aac820e3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-link text-white </value>
      <webElementGuid>810f1f18-ddbd-476b-b170-3d68a9dbdfc3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://ptberkatkeselamatandunia.epizy.com/items</value>
      <webElementGuid>eab3d938-c8ec-4bbe-b12e-ba1b2f7d36a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            table_view
                        
                        Master Barang
                    </value>
      <webElementGuid>3652edf5-56aa-4b4e-b90d-c3ef416c9d3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;g-sidenav-show  bg-gray-200&quot;]/main[@class=&quot;main-content position-relative max-height-vh-100 h-100 border-radius-lg ps&quot;]/aside[@id=&quot;sidenav-main&quot;]/div[@id=&quot;sidenav-collapse-main&quot;]/ul[@class=&quot;navbar-nav&quot;]/li[@class=&quot;nav-item&quot;]/a[@class=&quot;nav-link text-white&quot;]</value>
      <webElementGuid>176190b1-1c14-4250-a992-78c07d835cd9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='sidenav-collapse-main']/ul/li[3]/a)[2]</value>
      <webElementGuid>04584b58-1e0e-4e8a-9b6b-4a7fac9f0207</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kategori Barang'])[2]/following::a[1]</value>
      <webElementGuid>72f4d78c-866f-40d5-8a2c-3cc57b400410</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='format_textdirection_r_to_l'])[2]/following::a[1]</value>
      <webElementGuid>6f51993e-9190-4d3e-a0e5-a606b9fa415b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[@href='http://ptberkatkeselamatandunia.epizy.com/items'])[2]</value>
      <webElementGuid>a80c9209-84d6-42e3-ab46-3aa3d6160b1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[3]/a</value>
      <webElementGuid>544c76eb-f6e5-4047-a7ad-dd16c52c3296</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://ptberkatkeselamatandunia.epizy.com/items' and (text() = '
                        
                            table_view
                        
                        Master Barang
                    ' or . = '
                        
                            table_view
                        
                        Master Barang
                    ')]</value>
      <webElementGuid>428d31f7-02d3-4ad0-af9e-b70d3b16a5c9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
