<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_format_textdirection_r_to_l              _cddb7d</name>
   <tag></tag>
   <elementGuidId>dd167ad2-6241-4849-b0b4-1a3737d7ee14</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='sidenav-collapse-main']/ul/li[2]/a)[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b26cbf8e-fc63-49f2-8cd2-8777ce786b62</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-link text-white </value>
      <webElementGuid>7a7609d3-6967-4151-b925-018418f11aec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/categories</value>
      <webElementGuid>4a787f79-11d8-4ba2-8056-dbb9f360a496</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    
                    format_textdirection_r_to_l
                    
                    Kategori Barang
                    </value>
      <webElementGuid>176676f7-01a3-4b75-8097-15592a6ecd1d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;g-sidenav-show  bg-gray-200&quot;]/main[@class=&quot;main-content position-relative max-height-vh-100 h-100 border-radius-lg ps&quot;]/aside[@id=&quot;sidenav-main&quot;]/div[@id=&quot;sidenav-collapse-main&quot;]/ul[@class=&quot;navbar-nav&quot;]/li[@class=&quot;nav-item&quot;]/a[@class=&quot;nav-link text-white&quot;]</value>
      <webElementGuid>c8040af5-0d8f-401d-89fd-2fed514f11ba</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='sidenav-collapse-main']/ul/li[2]/a)[2]</value>
      <webElementGuid>e3d515d4-6bbd-4f99-bcfc-aace9f28298d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[2]/following::a[1]</value>
      <webElementGuid>d8ecd26b-2c68-43b9-8a2d-d8603400fe01</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='dashboard'])[2]/following::a[1]</value>
      <webElementGuid>eb28f746-9604-406c-a0a0-eb7ed2d06787</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/categories')])[2]</value>
      <webElementGuid>3b520f32-ae55-47d2-9cdf-9b7922c78a93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[2]/a</value>
      <webElementGuid>47edae79-1344-4fbd-adc1-0146cfe0ee9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/categories' and (text() = '
                    
                    format_textdirection_r_to_l
                    
                    Kategori Barang
                    ' or . = '
                    
                    format_textdirection_r_to_l
                    
                    Kategori Barang
                    ')]</value>
      <webElementGuid>59e11621-eeb7-4856-a6b9-dc1e432eed49</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
