<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_local_shipping                           _6fe299</name>
   <tag></tag>
   <elementGuidId>581ee903-4cb6-4f51-a35a-6875e9ab4b40</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='sidenav-collapse-main']/ul/li[5]/a)[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>cfa0dfe7-f1f6-499d-9e2e-122f35908abf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-link text-white </value>
      <webElementGuid>c9a21a38-a45c-4d63-b5e0-028c88ed9da2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://ptberkatkeselamatandunia.epizy.com/outitems</value>
      <webElementGuid>5c143f98-06d2-46e4-bd60-f69a12f5d8ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            local_shipping
                        
                        Pencatatan Stok Keluar
                    </value>
      <webElementGuid>7956c1ce-d657-4fd6-bead-f12a0546d0be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;g-sidenav-show  bg-gray-200&quot;]/main[@class=&quot;main-content position-relative max-height-vh-100 h-100 border-radius-lg ps&quot;]/aside[@id=&quot;sidenav-main&quot;]/div[@id=&quot;sidenav-collapse-main&quot;]/ul[@class=&quot;navbar-nav&quot;]/li[@class=&quot;nav-item&quot;]/a[@class=&quot;nav-link text-white&quot;]</value>
      <webElementGuid>7c5d1107-f7b9-42cc-a642-1ce71496f9c3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='sidenav-collapse-main']/ul/li[5]/a)[2]</value>
      <webElementGuid>59bb7a83-bd32-4c1b-8e00-b3228ba1dc8c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pencatatan Stok Masuk'])[1]/following::a[1]</value>
      <webElementGuid>9b8b2ace-871a-4ea6-ab32-32d5e2bbff9f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='shopping_cart'])[1]/following::a[1]</value>
      <webElementGuid>0039de29-f67c-459b-82b2-84574f2b71af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[@href='http://ptberkatkeselamatandunia.epizy.com/outitems']</value>
      <webElementGuid>416031be-4ed0-4353-b75d-3dca9c15ceaa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[5]/a</value>
      <webElementGuid>a4c0fb8d-f9ab-4cf3-9b9b-3e5580a7931f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://ptberkatkeselamatandunia.epizy.com/outitems' and (text() = '
                        
                            local_shipping
                        
                        Pencatatan Stok Keluar
                    ' or . = '
                        
                            local_shipping
                        
                        Pencatatan Stok Keluar
                    ')]</value>
      <webElementGuid>8230383b-9c2a-40a2-8172-42ca8cf3bc15</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
